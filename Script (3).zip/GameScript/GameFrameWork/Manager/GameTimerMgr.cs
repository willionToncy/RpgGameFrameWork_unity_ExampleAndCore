using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Proxy;

public class GameTimerMgr: Proxy
{
    public GameTimerMgr(string ProxyName, object Date = null) :base(ProxyName, Date)
    {

    }
}
