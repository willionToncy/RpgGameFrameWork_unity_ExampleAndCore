using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IPoolInterfface<T>
{
    public abstract bool IsEntityPool();
    public abstract int GetObjectCount();
    public abstract IPoolInterfface<T> Init();
    public abstract void Destroy();
    public abstract void clearObject(int Index);
    public abstract T GetObject();
}
