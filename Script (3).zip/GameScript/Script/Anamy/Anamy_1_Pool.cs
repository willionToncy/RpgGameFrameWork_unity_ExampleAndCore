using SimpleFramework;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Anamy_1_Pool : IPoolInterfface<GameObject>
{
    LinkedList<GameObject> PoolDic;

    public bool IsEntityPool() 
    {
        return true;
    }
    public int GetObjectCount() 
    {
        throw new System.NotImplementedException();
    }
    public IPoolInterfface<GameObject> Init()
    {
        PoolDic=new LinkedList<GameObject>();
        return this;
    }
    public void Destroy()
    {
        throw new System.NotImplementedException();
    }
    public void clearObject(int Index) 
    {
        throw new System.NotImplementedException();
    }
    public GameObject GetObject() 
    {
        return PoolDic.First.Value;
    }
}

public class Anamy_1_PoolFactory : IObjPoolFactory<GameObject>
{
    public IPoolInterfface<GameObject> CreateObjPool()
    {
        return new Anamy_1_Pool();
    }

}