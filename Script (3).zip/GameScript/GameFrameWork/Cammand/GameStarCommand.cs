using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Command;
using PureMVC.Interfaces;
using UnityEngine.Rendering;
using System;
using System.IO;
using static TreeEditor.TreeEditorHelper;

public class GameStarCommand : SimpleCommand
{
    ModelMager modelMager = ModelMager.Instance;
    public override void Execute(INotification notification)
    {
        ConfigRead configRead = new ConfigRead();
        ModelConfigInput modelConfigInput = new ModelConfigInput();
        configRead.InitStarConfigRead("\\Date\\ConfigDate\\GameModelStar.json");
        configRead.GetConfigByObject(modelConfigInput);
        for (int i = 0; i < modelConfigInput.modelModels.Length; i++)
        {
            ModelType modelType = modelConfigInput.modelModels[i];
            try 
            {
                GameFacade.instanceFacade.ExecuteCoreResqust(modelType.Modeltype, modelType.ModelName);
            }
            catch (Exception e)
            {
                using (StreamWriter sr = new StreamWriter(Application.dataPath + @"/Date/Logs/inputModelsLogs.text",true))
                {
                    modelType = modelConfigInput.modelModels[i];
                    sr.WriteLine("InputJson : " + modelType.Modeltype);
                    sr.WriteLine("failure");
                    sr.WriteLine(e.Message);
                    sr.WriteLine(e.TargetSite);
                    sr.WriteLine("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
                    sr.Close();
                    sr.Dispose();
                };
            }
        }
    }
}

public class ModelConfigInput
{
    public ModelType[] modelModels=new ModelType[1];
}

public class ModelType
{
    public ModelType() 
    {
        ModelName = "define";
        Modeltype = "define";
        ModelId = "define";
    }
    /// <summary>
    /// ��ʽΪ��ModelType(string name,string type,string id) 
    /// </summary>
    /// <param name="name"></param>
    /// <param name="type"></param>
    /// <param name="id"></param>
    public ModelType(string name, string type, string id)
    {
        ModelName = name;
        Modeltype = type;
        ModelId = id;
    }
    public string ModelName;
    public string Modeltype;
    public string ModelId;
}