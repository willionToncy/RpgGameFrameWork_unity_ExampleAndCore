using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using LitJson;
using System.Xml;
using System.IO;

public class ConfigWriter
{
    string outPath=null;
    object Date = null;
    /// <summary>
    /// ��ʼ��д��������һ����Ϊ����ڹ���·�����ڶ�����ΪҪ�洢��Json�������ࣻ
    /// </summary>
    /// <param name="path"></param>
    /// <param name="Date"></param>
    /// <returns></returns>
    public bool InitConfigWriter(string path, object Date)
    {
        outPath = Application.dataPath + path;
        this.Date = Date;
        if (outPath != null && Date != null) return true;
        else return false;
    }
    /// <summary>
    /// ��ʼ����ֱ�ӵ��ü���
    /// </summary>
    /// <param name="Date"></param>
    public bool WriteDate() 
    {
        string outputString=JsonMapper.ToJson(Date);
        using (StreamWriter sWriter = new StreamWriter(outPath))
        {
            sWriter.WriteLine(outputString);
            sWriter.Close();
            sWriter.Dispose();
            return true;
        }
    }
}
