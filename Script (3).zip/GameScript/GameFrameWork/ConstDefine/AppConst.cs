﻿using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

namespace SimpleFramework {
    public class AppConst {
        public const bool DebugMode = true;                        //调试模式-用于内部测试

        public const int TimerInterval = 1;
        public const int GameFrameRate = 30;                       //游戏帧频
        public const int AnamyPool_Default_Number = 20;            //AnamyObjectPool默认数量


        public const string AppName = "Car Run";                    //游戏名称
        public const string AppPrefix = AppName + "_";             //应用程序前缀
    }
}