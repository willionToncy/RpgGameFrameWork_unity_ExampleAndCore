using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillDelopy : MonoBehaviour
{
    public ISkill skill;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
