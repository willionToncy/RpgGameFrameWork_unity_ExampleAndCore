using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns;
using PureMVC.Interfaces;
using PureMVC.Patterns.Command;
using static UnityEngine.InputSystem.InputAction;


[ModelType(true, false, "PlayerSkillCommand", "Command")]
public class PlayerSkillCommand : SimpleCommand,IMyModel
{
    public bool Init()
    {
       return true;
    }
    public IMyModel Clone()
    {
        
         PlayerSkillCommand tmp= new PlayerSkillCommand();
         tmp=(PlayerSkillCommand)this.MemberwiseClone();
         return tmp;
    }

    public override void Execute(INotification notification)
    {
        CallbackContext massage = (CallbackContext)notification.Body;
        IProxy gameObjectctMgr = GameFacade.instanceFacade.RetrieveProxy("GameObjectMgr");
        
        Debug.Log(gameObjectctMgr.ToString());
        Debug.Log(massage.action.name);
    }

    public List<string> GetEventList()
    {
        throw new System.NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    public IMyModel GetThisObject()
    {
       return this;
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }
}
