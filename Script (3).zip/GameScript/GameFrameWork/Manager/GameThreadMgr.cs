using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Proxy;
using UnityEditor.Animations;

public class GameThreadMgr: Proxy
{
    public GameThreadMgr(string proxyName, object data = null):base(proxyName, data)
    {
    }
}
