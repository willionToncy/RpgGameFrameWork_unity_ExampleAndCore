using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;
using UnityEngine.UIElements;
using static UnityEngine.Video.VideoPlayer;

public class ModelEventMassage : IEnumerable
{
    Dictionary<string, EventHandler<EventArgs>> ModelEventDic=new Dictionary<string, EventHandler<EventArgs>>();
    public EventHandler<EventArgs> GetExecuteFunc(string EventName)
    {
        if (ModelEventDic.ContainsKey(EventName))
            return ModelEventDic[EventName];
        return null;
    }
   
    public void SetEventSubDict(string EventName, EventHandler<EventArgs> eventHandler)
    {
        if (!ModelEventDic.ContainsKey(EventName)) ModelEventDic.Add(EventName, eventHandler);
        else
        {
            
            ModelEventDic[EventName]+= eventHandler;
        }
        
    }
    public List<string> GetEventSubList()
    {
        List<string> EventNameList = new List<string>();
        foreach (KeyValuePair<string, EventHandler<EventArgs>> keyValuePair in ModelEventDic)
        {
            EventNameList.Add(keyValuePair.Key);
        }
        return EventNameList;
    }

    public IEnumerator GetEnumerator()
    {
        return ModelEventDic.GetEnumerator();
    }
}
