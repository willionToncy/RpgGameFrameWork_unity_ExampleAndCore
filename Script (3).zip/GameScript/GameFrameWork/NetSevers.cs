using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Proxy;

public class NetSevers : Proxy
{
    public NetSevers(string proxyName, object data = null): base(proxyName, data) 
    { 
    }
}
