using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.ResourceManagement.AsyncOperations;
using static UnityEngine.AddressableAssets.Addressables;

public class SkillManager<T> : MonoBehaviour,ISkillManager
{
    string _gameMgrName;
    GameObject _skillRealseObj;
    Dictionary<string,T> _date;
    SkillPoolMgr _poolMgr;
    SkillReleaseMgr _releaseMgr;
    
    public GameObject GetSkillReleaseObj()
    {
        return _skillRealseObj;
    }

    public string GetSkillMgrName()
    {
        return _gameMgrName;
    }
    public void Init(string skillMgrName,GameObject skillRealseObj) 
    {
        _skillRealseObj=skillRealseObj;
        _gameMgrName = skillMgrName;
        _date=new Dictionary<string,T>();
        _poolMgr = (SkillPoolMgr)GameFacade.instanceFacade.RetrieveProxy("SkillPoolMgr");
        _releaseMgr = (SkillReleaseMgr)GameFacade.instanceFacade.RetrieveProxy("SkillReleaseMgr");
    }
    public void AddSkillDate(string Name,T Value)
    {
        _date.Add(Name, Value);
    }
    public ISkill ProperSkill(string SkillName)
    {
        ISkill skill = null;
        skill=_poolMgr.GetSkill(SkillName);
        skill.InitSkill<T>(_date[SkillName]);
        return skill; 
    }
    public bool GenerateSkills(string SkillName)
    {
        ISkill skill = ProperSkill(SkillName);
        if (_releaseMgr.CanRelease(skill)) 
        {
            skill.Execate();
            return true;
        }
        return false;
    }

    
}
