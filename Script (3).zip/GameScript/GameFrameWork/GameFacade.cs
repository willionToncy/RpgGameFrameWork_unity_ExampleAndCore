using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns;
using PureMVC.Patterns.Facade;
using PureMVC.Core;
using PureMVC.Interfaces;
using System;
using PureMVC.Patterns.Mediator;
using PureMVC.Patterns.Proxy;
using System.IO;
using Unity.VisualScripting;

public class GameFacade : Facade,ICoreHandler
{
    public GameObject GameMianObject;
    public EventManger eventManger;
    public ModelMager modelMager;
    public GameObjectJobSystemMgr jobSystemMgr;
    public static GameFacade instanceFacade
    {
        get
        {
            if (instance == null)
            {
                instance = new GameFacade();
            }
            return instance as GameFacade;
        }
    }
    private  ICoreHandler _coreNextHadle= null;
    private GameFacade() 
    {
        InitializeFacade();
    }
    override protected void InitializeFacade() 
    {
        modelMager = ModelMager.Instance;
        eventManger = EventManger.Instance;
        
        _coreNextHadle = modelMager;
        base.InitializeFacade();
    }
    override protected void InitializeModel()
    {
       base.InitializeModel();
    }
    override protected void InitializeView()
    {
        base.InitializeView();
    }
    override protected void InitializeController()
    {
        base.InitializeController();
    }
    public void starGame() 
    {
        GameMianObject = GameObject.Find("GameMianObject");
        GameObject.DontDestroyOnLoad(GameMianObject);
        jobSystemMgr = GameMianObject.GetComponent<GameObjectJobSystemMgr>();
        this.RegisterCommand("starGameFramWork", " GameStarCommand");
        SendNotification("starGameFramWork");
    }
    /// <summary>
    /// ��һ����Ϊ��������ע��һ����Ӧ��Ӧ����ڶ�����Ϊ���������ơ�
    /// ������tips���뱣������ű�������������һ�£���һ������ᷢ������
    /// </summary>
    /// <param name="CommandName"></param>
    /// <param name="ScriptName"></param>
    public void RegisterCommand(string CommandName, string ScriptName)
    {
        base.RegisterCommand(CommandName,() => {
            Type type=Type.GetType(ScriptName);
            return (ICommand)Activator.CreateInstance(type);
        });
    }
    public new void RegisterCommand(string notificationName, Func<ICommand> factory) 
    {
        base.RegisterCommand(notificationName, factory);
    }

    public void ExecuteCoreResqust(string modelKind, string Name)
    {
        Type type = Type.GetType(modelKind);
        if (((ModelTypeAttribute)type.GetAttribute(typeof(ModelTypeAttribute))).GetModelType() == "Command")
        {
            ExecuteCoreResqust((IMyModel)Activator.CreateInstance(type), Name);
        }
        else ExecuteCoreResqust((IMyModel)Activator.CreateInstance(type, new string[1] { modelMager.GetModelAttribute(modelKind).GetModelClassName() }), Name);

    }
    public void ExecuteCoreResqust(IMyModel myModel, string NameInDivct)
    {
        string ModelClassName = modelMager.GetModelAttribute(myModel).GetModelClassName();
        string modelKind = modelMager.GetKindofMVC(myModel);
        if (modelKind != "false")
        {
            if (modelKind == "Command")
            {
                RegisterCommand(NameInDivct, () => { return (ICommand)Activator.CreateInstance(Type.GetType(ModelClassName)); });
            }
            else if (modelKind == "Mediator")
            {
                RegisterMediator((Mediator)myModel);
            }
            else if (modelKind == "Proxy")
            {
                RegisterProxy((Proxy)myModel);
            }
        }
        _coreNextHadle?.ExecuteCoreResqust(myModel, NameInDivct);
        using (StreamWriter sr = new StreamWriter(Application.dataPath + @"/Date/Logs/inputModelsLogs.text", true))
        {
            sr.WriteLine("InputJson : " + modelKind);
            sr.WriteLine("susscess");
            sr.WriteLine("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
            sr.Close();
            sr.Dispose();
        }
    }
    public ICoreHandler GetCoreNextHandler()
    {
        return _coreNextHadle;
    }

    public void SetCoreNextHandler(ICoreHandler data)
    {
        _coreNextHadle = data;
    }

    #region ��������
    //public void RegisterModel(IMyModel myModel, string NameInDivct)
    //{
    //    string ModelClassName = modelMager.GetModelAttribute(myModel).GetModelClassName();
    //    string modelKind = modelMager.GetKindofMVC(myModel);
    //    if (modelKind != "false")
    //    {
    //        if (modelKind == "Command")
    //        {
    //            RegisterCommand(NameInDivct, () => { return (ICommand)Activator.CreateInstance(Type.GetType(ModelClassName)); });
    //        }
    //        else if (modelKind == "Mediator")
    //        {
    //            RegisterMediator((Mediator)myModel);
    //        }
    //        else if (modelKind == "Proxy")
    //        {
    //            RegisterProxy((Proxy)myModel);
    //        }
    //    }
    //    if (modelMager.GetModelAttribute(myModel).IsSubEvent())
    //    {
    //        foreach (var tmp in myModel.GetEventList())
    //        {
    //            try
    //            {
    //                eventManger.AddEvent(tmp, null);
    //            }
    //            catch (EventExcepction ex)
    //            {
    //                using (StreamWriter streamWriter = new StreamWriter(Application.dataPath + "\\Date\\logs\\EventReadlogs.text", true))
    //                {
    //                    streamWriter.WriteLine(ex.Message + "/n");
    //                    streamWriter.WriteLine("______________________________________________");
    //                }

    //            }
    //        }
    //        foreach (KeyValuePair<string, EventHandler<EventArgs>> tmp in myModel.GetEventMassage())
    //        {
    //            try
    //            {
    //                eventManger.AddEvent(tmp.Key, tmp.Value);
    //                return;
    //            }
    //            catch (EventExcepction ex)
    //            {
    //                using (StreamWriter streamWriter = new StreamWriter(Application.dataPath + "\\Date\\logs\\EventReadlogs.text", true))
    //                {
    //                    streamWriter.WriteLine(ex.Message + "/n");
    //                    streamWriter.WriteLine("______________________________________________");
    //                    streamWriter.Close();
    //                    streamWriter.Dispose();
    //                }

    //            }
    //            eventManger.Subscribe(tmp.Key, tmp.Value);
    //        }
    //    }
    //    using (StreamWriter streamWriter = new StreamWriter(Application.dataPath + "\\Date\\logs\\ModelAddlogs.text"))
    //    {
    //        streamWriter.WriteLine("ModelClass:" + ModelClassName + ";");
    //        streamWriter.WriteLine("ModelName:" + NameInDivct + ";");
    //        streamWriter.WriteLine("______________________________________________");
    //        streamWriter.Close();
    //        streamWriter.Dispose();
    //    }
    //    modelMager.AddModle(myModel, NameInDivct);
    //}
    //public void RegisterModel(string modelKind, string Name)
    //{
    //    Type type = Type.GetType(modelKind);
    //    if (((ModelTypeAttribute)type.GetAttribute(typeof(ModelTypeAttribute))).GetModelType() == "Command")
    //    {
    //        RegisterModel((IMyModel)Activator.CreateInstance(type), Name);
    //    }
    //    else RegisterModel((IMyModel)Activator.CreateInstance(type, new string[1] { modelMager.GetModelAttribute(modelKind).GetModelClassName() }), Name);
    //    using (StreamWriter sr = new StreamWriter(Application.dataPath + @"/Date/Logs/inputModelsLogs.text", true))
    //    {
    //        sr.WriteLine("InputJson : " + modelKind);
    //        sr.WriteLine("susscess");
    //        sr.WriteLine("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
    //        sr.Close();
    //        sr.Dispose();
    //    }
    //}
    #endregion 
}
