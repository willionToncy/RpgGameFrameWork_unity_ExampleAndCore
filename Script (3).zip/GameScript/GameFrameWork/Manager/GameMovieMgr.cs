using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Mediator;

public class GameMovieMgr:Mediator
{
    public GameMovieMgr(string mediatorName, object viewComponent = null):base(mediatorName, viewComponent)
    {
    }
}
