using PureMVC.Interfaces;
using PureMVC.Patterns.Proxy;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

[ModelType(true, false, "SkillPoolMgr", "Proxy")]

public class SkillPoolMgr:Proxy,IMyModel
{
    SkillTargeMgr SkillTargeMgr;
    Dictionary<string,LinkedList<ISkill>> SkillDict;
    Dictionary<string ,ISkillFactory> _skillFactoryDict;
    public SkillPoolMgr(string proxyName, object data = null) : base(proxyName, data)
    {
    }
   
    #region �ӿ�ʵ��
    public bool Init()
    {
        SkillDict=new Dictionary<string,LinkedList<ISkill>>();
        SkillTargeMgr= (SkillTargeMgr)GameFacade.instanceFacade.RetrieveProxy("SkillTargeMgr");
        return true;
    }

    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    {
        throw new NotImplementedException();
    }

    public IModelMassage GetModelMassage()
    {
        throw new NotImplementedException();
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        throw new NotImplementedException();
    }

    public List<string> GetEventList()
    {
        throw new NotImplementedException();
    }
    #endregion
    
    public ISkill GetSkill(string SkillName)
    {
        LinkedList<ISkill> skilllist = null;
        if (SkillDict.TryGetValue(SkillName, out skilllist))
        {
            Debug.LogWarning("���ܲ�����");
            return null;
        }
        if (skilllist != null)
        {
            return skilllist.First.Value;
        }
        return CreaterSkill(SkillName);
    }

    #region �ڲ���������
    private ISkill CreaterSkill(string SkillName)
    {
        ISkill skill = null;
        MyConfigReadWrite myConfigReadWrite = null;
        ConfigReaderEventMassage configReaderEventMassage = new ConfigReaderEventMassage();
        configReaderEventMassage.Path = @"/Date/userDate/SkillDate/SkillStructure_Player_1.json";
        configReaderEventMassage.ReturnConfigReader = (MyConfigReadWrite obj) =>
        {
            myConfigReadWrite = obj;
        };
        GameFacade.instanceFacade.eventManger.PublishMassage("GetConfigReader", this, configReaderEventMassage);
        SkillTargeStructure skillTargeStructure = new SkillTargeStructure();
        myConfigReadWrite.GetConfigByObject(skillTargeStructure);
        skill = _skillFactoryDict[SkillName].Creater();
       
    }
    private ISkillTarge ReaderSkilllStucture(SkillTargeStructure skillTargeStructure��
    {
        foreach (var tmp in skillTargeStructure.skillTarges) 
        {
            ISkillTarge skillTarge = SkillTargeMgr.GetSkillTarge(skillTargeStructure.SkillName, tmp);
        }
        foreach (var tmp in skillTargeStructure.skillTargeStructures) 
        {

        }
    }
    #endregion
}

public class SkillTargeStructure
{
    public string SkillName;
    public string[] skillTarges;
    public SkillTargeStructure[] skillTargeStructures;
}