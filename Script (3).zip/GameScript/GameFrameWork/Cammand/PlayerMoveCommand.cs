using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns;
using PureMVC.Patterns.Command;
using PureMVC.Interfaces;
using System.Threading;
using static UnityEngine.InputSystem.InputAction;


[ModelType(true, false, "PlayerMoveCommand", "Command")]
public class PlayerMoveCommand :SimpleCommand,IMyModel
{
    public IMyModel Clone()
    {
       PlayerMoveCommand tmp= new PlayerMoveCommand();
       tmp=(PlayerMoveCommand)this.MemberwiseClone();
        return tmp;
    }

    public override void Execute(INotification notification)
    {
        CallbackContext massage = (CallbackContext)notification.Body;
        if (massage.action.name == "move")
        {
            Debug.Log(massage.ReadValue<Vector2>());
        }
        else if (massage.action.name == "run")
        {
            if (massage.started)
            {
                Debug.Log("pass down run");
            }
            else Debug.Log("up run");
        }
        else if (massage.action.name=="slow") 
        {

            if (massage.started)
            {
                Debug.Log("pass down slow");
            }
            else Debug.Log("up slow");
        }
    }

    public bool Init()
    {
        return true;
    }
    public List<string> GetEventList()
    {
        throw new System.NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    public IMyModel GetThisObject()
    {
        return this;
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }
}
