using Unity;
using UnityEngine;

public interface ISkillRelease 
{
    public bool IsRelease(GameObject ReleaseObject,SkillReleaseDate skillReleaseDate);
    public CdCaculateDate GetCdCaculateDate();
}