using JetBrains.Annotations;
using PureMVC.Patterns.Proxy;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Jobs;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering;
using static UnityEditor.ShaderGraph.Internal.KeywordDependentCollection;


[ModelType(true, false, "SkillReleaseMgr", "Proxy")]
public class SkillReleaseMgr:Proxy,IMyModel
{
    //��һ��KeyֵΪ���������ڶ���KeyֵΪ������������
    public Dictionary<string,Dictionary<string,ISkillRelease>> SkillReleaseDataDict;
    
    public SkillReleaseMgr(string proxyName, object data = null) : base(proxyName, data)
    {
        
    }

    #region �ӿ�ʵ��

    public bool Init()
    {
        SkillReleaseDataDict = new Dictionary<string, Dictionary<string, ISkillRelease>>();
        return true;
    }
    public IMyModel GetThisObject()
    {
        return this;
    }
    public IMyModel Clone()
    {
        throw new System.NotImplementedException();
    }
    public List<string> GetEventList()
    {
        throw new System.NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }
    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }
    #endregion 

    public bool AddSkillReleaseDate(string skillName,ISkillManager skillManager,ISkillRelease skillRelease)
    {
        if (SkillReleaseDataDict.ContainsKey(skillName))
        {
            SkillReleaseDataDict[skillName].Add(skillManager.GetSkillReleaseObj().name, skillRelease);
        }
        else
        {
            SkillReleaseDataDict.Add(skillName, new Dictionary<string, ISkillRelease>());
            SkillReleaseDataDict[skillName].Add(skillManager.GetSkillReleaseObj().name, skillRelease);
        }
        return true;
    }
    public bool CanRelease(ISkill skillObject) 
    {
        Dictionary<string, ISkillRelease> tmpSkillDate;
        if (SkillReleaseDataDict.TryGetValue(skillObject.GetSkillName(), out tmpSkillDate))
        {
            if (SkillReleaseDataDict[skillObject.GetSkillName()][skillObject.GetSkillManager().GetSkillReleaseObj().name].GetCdCaculateDate().GetCdTime() < skillObject.GetReleaseDate().CdTime)
                return false;
            return tmpSkillDate[skillObject.GetSkillManager().GetSkillReleaseObj().name].IsRelease(skillObject.GetSkillManager().GetSkillReleaseObj(), skillObject.GetReleaseDate());
        }
        return false;
    }
    public void EnterCd(string SkillName, string ReleaseObjectName) 
    {
        SkillReleaseDataDict[SkillName][ReleaseObjectName].GetCdCaculateDate().SetCdTime(0.00f);
    }
    public void StarCdCaculate(string SkillName,string ReleaseObjectName)
    {
        if (SkillReleaseDataDict.ContainsKey(SkillName)) 
        {
            if (SkillReleaseDataDict[SkillName].ContainsKey(ReleaseObjectName))
            {
                CdCaculateDate cdCaculateDate= SkillReleaseDataDict[SkillName][ReleaseObjectName].GetCdCaculateDate();
                if (GameFacade.instanceFacade.jobSystemMgr.HasJob(SkillReleaseDataDict[SkillName][ReleaseObjectName].GetCdCaculateDate().GetId()))
                {
                    GameFacade.instanceFacade.jobSystemMgr.AddGameObject(cdCaculateDate, SkillReleaseDataDict[SkillName][ReleaseObjectName].GetCdCaculateDate().GetId(), "CdCaculate");
                }
                else 
                {
                    GameFacade.instanceFacade.jobSystemMgr.AddDateAndJob(cdCaculateDate,new CdCaculate(),SkillReleaseDataDict[SkillName][ReleaseObjectName].GetCdCaculateDate().GetId(), "CdCaculate");
                }
            }
        }
      
    }
}

public class CdCaculateDate : IMyJobSystemDate
{
    float CdTimeMax;
    float CdTime;
    public int GetId() 
    {
        return 2001001;
    }
    public float GetCdTime() 
    {
        return CdTime;
    }
    public void SetCdTime(float cdTime) 
    {
        CdTime=cdTime;
    }
    public void SetCdTimeMax(float cdTimeMax) 
    {
        CdTimeMax = cdTimeMax;
    }
    public List<float> GetDateToFloat()
    {
        return new List<float>()
        {
            CdTime,CdTimeMax
        };
    }

    public List<int> GetDateToInts()
    {
        return new List<int>()
        {
            0
        };
    }

    public int GetfloatLength()
    {
        return 1;
    }

    public int GetIntsLength()
    {
        return 0;
    }

    public bool SetDateByFloat(List<float> Date)
    {
        CdTime = Date[0];
        return true;
    }

    public bool SetDateByint(List<int> Date)
    {
        return true;
    }
}

public class CdCaculate : IMyJobSystemJob
{

    NativeArray<float> _Infloats;
    NativeArray<int> _Inints;
    IJobParallelFor _job;
    public JobHandle Excute(int batchArray, int BatchCount)
    {
        CdJob cdJob = new CdJob();
        cdJob.Infloats = _Infloats;
        cdJob.Inints = _Inints;
        return cdJob.Schedule(batchArray, BatchCount);
    }

    public NativeArray<float> GetOutfloats()
    {
        return _Infloats;
    }

    public NativeArray<int> GetOutints()
    {
        return _Inints;
    }

    public IMyJobSystemJob Init(NativeArray<float> Infloats, NativeArray<int> Inints)
    {
        _Infloats = Infloats;
        _Inints = Inints;
        return this;
    }

    public struct CdJob : IJobParallelFor
    {
        public NativeArray<float> Infloats;
        public NativeArray<int> Inints;
        public void Execute(int index)
        {
            if (Infloats[index * 2] < Infloats[index * 2 + 1]+0.01f) 
            {
                Infloats[index * 2] = Infloats[index * 2] + Time.deltaTime;
            }
        }
    }
}