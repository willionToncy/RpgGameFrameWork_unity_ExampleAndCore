using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Proxy;
using Unity.VisualScripting;
using System;

[ModelType(true,false,"GameSceneMgr","Proxy")]
public class GameSceneMgr: Proxy,IMyModel
{
    public GameSceneMgr(string proxyName) : base(proxyName) {}
    public GameSceneMgr(string proxyName, object data = null):base(proxyName, data)
    {
    }
    public bool Init()
    {
        return true;
    }
    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    {
        return (IMyModel)this.MemberwiseClone();
    }
    List<string> IMyModel.GetEventList()
    {
        throw new NotImplementedException();
    }

    ModelEventMassage IMyModel.GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    IModelMassage IMyModel.GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    void IMyModel.SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }
}
