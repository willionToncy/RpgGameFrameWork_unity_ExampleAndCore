using LitJson;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.SearchService;
using UnityEngine;
using static Unity.Burst.Intrinsics.X86.Avx;


[ModelType(false, true, "MyConfigReadWrite")]
public class MyConfigReadWrite :IMyModel
{
    ConfigRead configRead;
    static string Name;
    ConfigWriter configWriter;
    ModelEventMassage eventMassage;
    public MyConfigReadWrite()
    {
        Name = "MyConfigReadWrite";
        Init();
    }
    public MyConfigReadWrite(string name) 
    {
        Name = name;
        Init();
    }

    public bool Init() 
    {
        configRead = new ConfigRead();
        configWriter = new ConfigWriter();
        eventMassage = new ModelEventMassage();
        eventMassage.SetEventSubDict("GetConfigWriter", OnGetConfigWriter);
        eventMassage.SetEventSubDict("GetConfigReader", OnGetConfigReader);
        return true;
    }
    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    {
        return (IMyModel)this.MemberwiseClone();
    }
    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        return eventMassage;
    }

    public List<string> GetEventList()
    {
        return eventMassage.GetEventSubList();
    }

    public bool InitConfigWriter(string path, object Date) 
    {
        return configWriter.InitConfigWriter(path, Date);
    }

    public bool InitStarConfigRead(string fileRoute) 
    {
        if (configRead == null) 
        {
            configRead = new ConfigRead();
        }
        Debug.Log(fileRoute);
        configRead.InitStarConfigRead(fileRoute);
        Debug.Log(fileRoute);
        return true;
    }
    public bool SetPath(string path) 
    {
        configRead.InitStarConfigRead(path);
        return true;
    }        
    public bool WriteDate() 
    {
        return configWriter.WriteDate();
    }

    public string GetConfigDescription() 
    {
        if (configRead == null) 
        {
            Debug.LogError("ConfigRead is null");
            return null;
        }
        return configRead.GetConfigDescription();
    }
    public string GetConfigKind()
    {
        if (configRead == null)
        {
            Debug.LogError("ConfigRead is null");
            return null;
        }
        return configRead.GetConfigKind();
    }
    public string GetConfigName()
    {
        if (configRead == null)
        {
            Debug.LogError("ConfigRead is null");
            return null;
        }
        return configRead.GetConfigName();
    }
    public JsonData GetJsonDate() 
    {
        if (configRead == null)
        {
            Debug.LogError("ConfigRead is null");
            return null;
        }
        return configRead.GetJsonDate();
    }
    
    /// <summary>
    /// ͨ���������ֱ�ӻ�ԭjson��
    /// </summary>
    public object GetConfigByObject(object tmpObj) 
    {
        if (tmpObj == null)
        {
            Debug.LogError("tmpObj is null");
            return null;
        }
        if (configRead == null)
        {
            Debug.LogError("ConfigRead is null");
            return null;
        }
        return configRead.GetConfigByObject(tmpObj);
    }

    public void OnGetConfigWriter(object sender, EventArgs eventMassage) 
    {
        ConfigWriteEventMassage configReadWriteEventMassage = (ConfigWriteEventMassage)eventMassage;
        InitConfigWriter( configReadWriteEventMassage.Path, configReadWriteEventMassage.Date);
        configWriter.WriteDate();
    }
    public void OnGetConfigReader(object sender, EventArgs eventMassage)
    {
        
        ConfigReaderEventMassage configReadWriteEventMassage = (ConfigReaderEventMassage)eventMassage;
        Debug.Log(configReadWriteEventMassage.Path);
        InitStarConfigRead(configReadWriteEventMassage.Path);
        configReadWriteEventMassage.ReturnConfigReader(this);
    }
}

public class ConfigWriteEventMassage : EventArgs 
{
    public object Date;
    public string Path;
}

public class ConfigReaderEventMassage : EventArgs
{
    public string Path;
    public Action<MyConfigReadWrite> ReturnConfigReader;
}

