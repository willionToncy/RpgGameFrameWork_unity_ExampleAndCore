using NUnit.Framework;
using System.Collections.Generic;
using Unity;
using Unity.Collections;
using Unity.Jobs;
using UnityEditor.Build.Pipeline;
using UnityEngine;

public interface IMyJobSystemDate
{
	public int GetIntsLength();
	public int GetfloatLength();
    public List<int> GetDateToInts();
	public List<float> GetDateToFloat();
	public bool SetDateByFloat(List<float> Date);
	public bool SetDateByint(List<int> Date);
}

public interface IMyJobSystemJob 
{
	public IMyJobSystemJob Init(NativeArray<float> Infloats, NativeArray<int> Inints);
	public NativeArray<float> GetOutfloats();
	public NativeArray<int> GetOutints();

    public JobHandle Excute(int batchArray,int BatchCount);
}

