using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReadException : myException
{
    public ReadException(){ }
    public ReadException(string massage) : base(massage) { }

    public ReadException(string message, Exception inner) : base(message, inner) { }
}
