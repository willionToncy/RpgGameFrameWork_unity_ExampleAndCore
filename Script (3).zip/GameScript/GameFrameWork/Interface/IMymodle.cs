using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Unity.VisualScripting;

public interface IMyModel
{
    public bool Init();
    public IMyModel GetThisObject();
    public IMyModel Clone();
    public IModelMassage GetModelMassage();
    public void SetModelMassage(IModelMassage modelMassage);
    public ModelEventMassage GetEventMassage();
    public List<string> GetEventList();
}

public interface IModelMassage 
{
    public string GetModelName();
    public void SetModelName(string name);
    public string GetModelType();
    public void SetModelType(string type);
    public object Clone();
}
