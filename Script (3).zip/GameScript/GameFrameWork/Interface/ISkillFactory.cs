public interface ISkillFactory 
{
    public ISkill Creater();
}