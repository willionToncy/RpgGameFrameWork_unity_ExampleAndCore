#define Debug
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LitJson;
using System.IO;
using UnityEngine.UIElements;
using System.Reflection;
using System;
using Unity.VisualScripting;
using NUnit.Framework;
using Unity.Collections;

/// <summary>
/// �����ļ���ȡ�����ࡣ
/// </summary> 
public class ConfigRead : IConfigRead
{
    private JsonData jsonData;
    /// <summary>
    /// ����Ϊ�ļ������Assert��·��
    /// </summary>
    /// <param name="fileRoute"></param>
    public virtual void InitStarConfigRead(string fileRoute)
    {

        Debug.Log(fileRoute);
        try
        {
            jsonData = ReadJson(fileRoute);
        }
        catch (Exception e)
        {
            Debug.LogError(e.Message);
        }
        finally
        {
            using (StreamWriter streamWriter = new StreamWriter(Application.dataPath + @"\Date\logs\ReadJsonlogs.text", true))
            {
                string inputString = "";
                OutputJsonInformation(ref inputString);
                streamWriter.Write(inputString);
                streamWriter.WriteLine("//////////////////////////////////////");
                streamWriter.Close();
                streamWriter.Dispose();
            }
        }
    }
    /// <summary>
    /// ��ȡconfig�����ֶ�
    /// </summary>
    /// <returns></returns>
    public virtual string GetConfigDescription()
    {
        return (string)jsonData["Description"];
    }
    /// <summary>
    /// ��ȡ�����ļ�����
    /// </summary>
    /// <returns></returns>
    public virtual string GetConfigKind()
    {
        return (string)jsonData["kind"];
    }
    /// <summary>
    /// ��ȡ�����ļ�����
    /// </summary>
    /// <returns></returns>
    public virtual string GetConfigName()
    {
        return (string)jsonData["kind"];
    }
    /// <summary>
    /// ��ȡ�����ļ�����ֵ����һ������Ϊ��
    /// </summary>
    /// <param name="Key"></param>
    /// <returns></returns>
    public virtual string GetConfigValue(string Key)
    {
        return (string)jsonData[Key];
    }

    public virtual JsonData GetJsonDate()
    {
        return jsonData;
    }
    public virtual JsonData GetJsonObject(int index)
    {
        return jsonData[index];
    }

    public virtual JsonData GetJsonObject(string index)
    {
        return jsonData[index];
    }

    /// <summary>
    /// �������Json�����м�ֵ��
    /// </summary>
    /// <param name="json"></param>
    public void OutputJsonInformation(ref string inputString,JsonData json = null)
    {
        json = JsonDataSet(json);
        foreach (KeyValuePair<string, JsonData> tmp in json)
        {
            if (tmp.Value.IsArray)
            {
                inputString = inputString + "��������:" + ":"+tmp.Key+"\n"+"[\n";
                for (int i = 0; i < tmp.Value.Count; i++)
                {
                    OutputJsonInformation(ref inputString, tmp.Value[i]);
                    inputString = inputString +"]"+"\n";
                }
            }
            if (tmp.Value.IsObject
                &&!(tmp.GetType().IsValueType)
                && !(tmp.GetType()==typeof(string)))
            {
                inputString = inputString + "��������:" + tmp.Key + "\n";
                OutputJsonInformation(ref inputString, ((JsonData)tmp.Value));
            }
            inputString=inputString+tmp.Key + ":" + tmp.Value.ToString()+"\n";
        }
    }

    /// <summary>
    /// ͨ���������ֱ�ӻ�ԭjson��
    /// </summary>
    /// <param name="tmp"></param>
    /// <param name="json"></param>
    /// <returns></returns>
    public object GetConfigByObject(object tmpObj, JsonData json = null)
    {
        try 
        {
            Debug.Log(tmpObj.GetType().Name);
            string isInittrue = null;
            json = JsonDataSet(json);
            Array fieldInfoTmp = tmpObj.GetType().GetFields();
            foreach (FieldInfo field in fieldInfoTmp)
            {
                if (field.FieldType.IsArray)
                {
                    Array fieldArray = null;
                    foreach (KeyValuePair<string, JsonData> tmpJsonData in json)
                    {
                        
                        if (tmpJsonData.Key == field.Name)
                        {
                            Debug.Log(field.FieldType.GetElementType().IsBasic());
                            Debug.Log(tmpJsonData.Value.Count);
                            int indexCont = tmpJsonData.Value.Count;
                            if (field.FieldType.GetElementType().IsBasic())
                            {
                                SetFieldValue(tmpJsonData, field, tmpObj,indexCont);
                                break;
                            }
                            fieldArray = (Array)(Activator.CreateInstance(field.GetValue(tmpObj).GetType(), tmpJsonData.Value.Count));
                            for (int i = 0; i < indexCont; i++)
                            {
                                object obj = Activator.CreateInstance(field.FieldType.GetElementType());
                                fieldArray.SetValue(GetConfigByObject(obj, tmpJsonData.Value[i]), i);
                            }
                            field.SetValue(tmpObj, fieldArray);
                        }
                    }

                    continue;
                }
                if ((typeof(object).IsAssignableFrom(field.FieldType))
                    && !(field.FieldType.IsValueType)
                    && !(field.FieldType == typeof(string)))
                {
                    object obj = Activator.CreateInstance(field.FieldType);
                    foreach (KeyValuePair<string, JsonData> tmpJsonData in json)
                    {
                        if (tmpJsonData.Key == field.Name)
                        {
                            isInittrue = tmpJsonData.Key;
                            GetConfigByObject(obj, tmpJsonData.Value);
                            field.SetValue(tmpObj, obj);
                        }
                    }
                    continue;
                }
                foreach (KeyValuePair<string, JsonData> tmpJsonData in json)
                {
                    if (tmpJsonData.Key == field.Name)
                    {
                        isInittrue = tmpJsonData.Key;
                        SetFieldValue(tmpJsonData, field, tmpObj);
                    }
                }
            }
            return tmpObj;
        }
        catch (Exception e)
        { 
            Debug.LogError("Json Date Object Reader Failture:"+"\n"+e.Message+"\n"+ tmpObj.GetType().Name);
            return null;
        }
    }

    #region �ڲ���������

    private bool SetFieldValue(KeyValuePair<string, JsonData> tmpJsonData, FieldInfo field, object tmpObj,int indexCont=0)
    {
        if (field.FieldType == typeof(int))
        {
            field.SetValue(tmpObj, (int)tmpJsonData.Value);
            return true;
        }
        if (field.FieldType == typeof(string))
        {
            field.SetValue(tmpObj, (string)tmpJsonData.Value);
            return true;
        }
        if (field.FieldType == typeof(double))
        {
            field.SetValue(tmpObj, (double)tmpJsonData.Value);
            return true;
        }
        if (field.FieldType.GetElementType() == typeof(int)&&indexCont!=0) 
        {
            int[] tmpfield = new int[indexCont];
            for (int i = 0; i < indexCont; i++)
            {
                Debug.Log(tmpJsonData.Value[i]);
                tmpfield[i] = (int)tmpJsonData.Value[i];
            }
            field.SetValue(tmpObj, tmpfield);
            return true;
        }
        if (field.FieldType.GetElementType() == typeof(string) && indexCont != 0)
        {
            string[] tmpfield = new string[indexCont];
            for (int i = 0; i < indexCont; i++)
            {
                Debug.Log(tmpJsonData.Value[i]);
                tmpfield[i] =(string)tmpJsonData.Value[i];
            }
            field.SetValue(tmpObj, tmpfield);
            return true;
        }
        if (field.FieldType.GetElementType() == typeof(double) && indexCont != 0)
        {
            double[] tmpfield = new double[indexCont];
            for (int i = 0; i < indexCont; i++)
            {
                Debug.Log(tmpJsonData.Value[i]);
                tmpfield[i] =(double)tmpJsonData.Value[i];
            }
            field.SetValue(tmpObj, tmpfield);
            return true;
        }
        else
        {
            return false;
        }
    }

    JsonData ReadJson(string fileRoute)
    {
        string readDate = null;
        string readPath = null;
        readPath = Application.dataPath + fileRoute;
        using (StreamReader sRead = File.OpenText(readPath))
            readDate = sRead.ReadToEnd();
        if (readDate == null)
        {
            throw new ReadException("GameStar fail,Config is null");
        }
        return JsonMapper.ToObject(readDate);
    }

    private bool JsonDataIsNull(JsonData tmp) 
    {
        if (tmp == null) return true;
        else return false;
    }

    private JsonData JsonDataSet(JsonData tmp) 
    {
        if (JsonDataIsNull(tmp))
        {
            Debug.Log("��ȡ��ʼ");
            return tmp = jsonData;
        }
        else return tmp;
    }
    #endregion
}
