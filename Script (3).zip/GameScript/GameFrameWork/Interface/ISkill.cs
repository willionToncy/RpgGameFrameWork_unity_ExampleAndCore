using System.Collections.Generic;
using UnityEngine;

public interface ISkill
{
    ISkillTarge skillTarge { get; set;}
    public void Execate();
    public void InitSkill<T>(T Date);
    public void SetGameObject(GameObject objTmp);
    public SkillReleaseDate GetReleaseDate();
    public ISkill GetSkill();
    public string GetSkillName();

    public ISkillManager GetSkillManager();
}