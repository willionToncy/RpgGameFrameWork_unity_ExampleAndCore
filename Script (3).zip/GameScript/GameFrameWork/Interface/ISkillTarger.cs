using System.Collections.Generic;
using Unity.VisualScripting;

public interface ISkillTarge
{
    public ISkillTarge Clone();
    public string Name { get; }
    public string SkillID { get; }
    public bool Initiative<T>(T SkillDate);
    public void Execute();
    public bool AddChildSkill(ref ISkillTarge skillTarge);
    public bool RemoveChildSkill(in ISkillTarge skillTarge);
    public LinkedList<ISkillTarge> GetChilders();

}