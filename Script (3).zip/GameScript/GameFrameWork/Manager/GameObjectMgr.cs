using Palmmedia.ReportGenerator.Core;
using PureMVC.Interfaces;
using PureMVC.Patterns.Proxy;
using SimpleFramework;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;
using Unity.VisualScripting;
using Unity.VisualScripting.FullSerializer;
using UnityEngine;

[ModelType(true,true,"GameObjectMgr","Proxy")]
public class GameObjectMgr : Proxy, IMyModel
{
    MyConfigReadWrite myConfigReadWrite;
    GameObject PlayerGameOject;
    Dictionary<string, GameObject> GameObjDirt;
    Dictionary<string, IPoolInterfface<GameObject>> GameObjPoolDirt;
    ModelEventMassage modelEventMassage=new ModelEventMassage();
    public new const string NAME = ManagerName.ObjectMgr;
    public GameObjectMgr(string proxyName) : base(proxyName) 
    {
        Init();
    }
    public GameObjectMgr(string proxyName, object data = null):base(proxyName, data)
    {
        Init();
    }

    public bool Init()
    {
        Debug.Log("Init GameObjectMgr Model");
        GameObjDirt = new Dictionary<string, GameObject>();
        GameObjPoolDirt = new Dictionary<string, IPoolInterfface<GameObject>>();
        PlayerGameOject = Resources.Load<GameObject>("Player");
        PlayerGameOject.AddComponent<PlayerScript>();
        Debug.Log("Load Player Obj");
        PlayerGameOject = GameObject.Instantiate(PlayerGameOject);
        ConfigReaderEventMassage configReaderEventMassage = new ConfigReaderEventMassage();
        configReaderEventMassage.Path = @"/Date/userDate/GamePooolConfigArray.json";
        configReaderEventMassage.ReturnConfigReader = (MyConfigReadWrite obj) =>
        {
            myConfigReadWrite = obj;
        };
        GameFacade.instanceFacade.eventManger.PublishMassage("GetConfigReader", this, configReaderEventMassage);
        GamePoolConfigArray gamePoolConfigArray = new GamePoolConfigArray();
        Debug.Log("Init GamePool");
        gamePoolConfigArray = (GamePoolConfigArray)(myConfigReadWrite.GetConfigByObject(gamePoolConfigArray));
        foreach (string name in gamePoolConfigArray.GamePoolArray) 
        {
            CreaterGameObjectPool<GameObject>(name+"Factory");
            Debug.Log("Create GamePool:" + name);
        }
        Debug.Log("Game Object Manager MOdel Init is finished");
        myConfigReadWrite = null;
        return true;

    }
    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    {
        return (IMyModel)this.MemberwiseClone();
    }

    public ModelEventMassage GetEventMassage()
    {
       return modelEventMassage;
    }

    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }

    public List<string> GetEventList()
    {
        return new List<string>();
    }
    public GameObject GetGameObjByName(string name) 
    {
        if (GameObjDirt.ContainsKey(name))
        {
            return GameObjDirt[name];
        }
        else 
        {
            Debug.LogError("û���������"+name);
            return null;
        }
    }
   

    public GameObject GetPalyer() 
    {
        return PlayerGameOject;
    }

   
    public GameObject GetGameObjbyPool(string Name) 
    {
        return GameObjPoolDirt[Name].GetObject();
    }
    public IPoolInterfface<GameObject> GetGameObjPool(string Name) 
    {
        return GameObjPoolDirt[Name];
    }
    public bool CreaterGameObjectPool<T>(string Name) 
    {
        try
        {
            Type type = Type.GetType(Name);
            object obj = Activator.CreateInstance(type);
            Debug.Log($"ͨ����������{Name}���������");
            return CreaterGameObjectPool<T>(Name,(IObjPoolFactory<T>)obj);

        }
        catch (Exception e)
        {
            Debug.LogError($"����{Name}�����ʧ��" + e.ToString());
            return false;
        }
    }

    public bool AddGameObjectPool<T>(string Name) 
    {
        Type type = Type.GetType(Name);
        object obj = Activator.CreateInstance(type);
        Debug.Log($"ֱ��ѹ��һ�Ѵ����Ķ���أ�{Name}");
       if (typeof(T) == typeof(GameObject))
              GameObjPoolDirt.Add(Name, obj as IPoolInterfface<GameObject>);
         return true;
    }
    public bool CreaterGameObjectPool<T>(string KindName,IObjPoolFactory<T> poolFactory)
    {
        return CreaterGameObjectPool<T>(KindName, poolFactory.CreateObjPool);
    }

    /// <summary>
    /// ����������������أ���һ����Ϊ��������֣��ڶ�������Ϊ����ع�������
    /// </summary>
    /// <param name="KindName"></param>
    /// <param name="poolFactory"></param>
    /// <returns></returns>
    public bool CreaterGameObjectPool<T>(string KindName,Func<IPoolInterfface<T>> poolFactory) 
    {
        if (GameObjPoolDirt.ContainsKey(KindName))
        {
            Debug.LogError("�Ѿ�����������" + KindName);
            return false;
        }
        else 
        {
            if (typeof(T) == typeof(GameObject))
                GameObjPoolDirt.Add(KindName, ((IPoolInterfface<GameObject>)poolFactory()).Init());
            return true;
        }
    }
}

class GamePoolConfigArray
{
    public string[] GamePoolArray=new string[0];
}
