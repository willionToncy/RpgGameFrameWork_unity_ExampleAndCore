using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using PureMVC.Patterns.Mediator;

public class GameMusicMgr:Mediator
{
    public GameMusicMgr(string mediatorName, object viewComponent = null):base(mediatorName, viewComponent)
    {
    }
}
