using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventExcepction :myException
{
    public EventExcepction() : base() { }
    public EventExcepction(string massage) : base(massage) { }
}
