using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Mediator;
using PureMVC.Interfaces;
using System;
using NUnit.Framework.Internal;
using UnityEngine.InputSystem;
using System.Runtime.InteropServices.WindowsRuntime;
using UnityEngine.UIElements;
using static UnityEngine.InputSystem.InputAction;
using System.Reflection;
using static TreeEditor.TreeEditorHelper;
using System.IO;

[ModelType(true, true, "MyInputManager", "Mediator")]
public class MyInputManager : Mediator, IMyModel
{
    Dictionary<string,IInputActionCollection2> InputClassDic;

    ModelEventMassage modelEventMassage=new ModelEventMassage();
    public MyInputManager(string mediatorName) : base(mediatorName)
    {
        using (StreamWriter sr = new StreamWriter(Application.dataPath + @"/Date/Logs/InputMgrModelsLogs.text", true))
        { 
            sr.WriteLine("��ʼ������");
            sr.WriteLine(Time.realtimeSinceStartup);
            sr.WriteLine("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
            sr.Close();
            sr.Dispose();
        };
        InputClassDic = new Dictionary<string, IInputActionCollection2>();
        Init();
        using (StreamWriter sr = new StreamWriter(Application.dataPath + @"/Date/Logs/InputMgrModelsLogs.text", true))
        {
            sr.WriteLine("��������");
            sr.WriteLine(Time.realtimeSinceStartup);
            sr.WriteLine("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
            sr.Close();
            sr.Dispose();
        };

    }
    public MyInputManager(string mediatorName, object viewComponent = null) : base(mediatorName, viewComponent)
    {
        InputClassDic = new Dictionary<string, IInputActionCollection2>();
        Init();
    }
   public bool Init()
    {
        UsePathDate usePathDate=new UsePathDate();
        InputClassDic.Add("PlayerDicControl", new PlayerDicControl());
        InputClassDic.Add("PlayerControl", new PlayerControl());
        InputClassDic.Add(" GameSysControl", new GameSysControl());
        InputClassDic.Add("PlayerSkill", new PlayerSkill());
        ConfigRead configRead = new ConfigRead();
        configRead.InitStarConfigRead(@"\Date\userDate\usePathDate.json");
        usePathDate = (UsePathDate)configRead.GetConfigByObject(usePathDate);
        ChangeBindPathbyUser(usePathDate);
        foreach (var tmp in InputClassDic) 
        {
            tmp.Value.Enable();
            foreach (var tmp2 in tmp.Value)
            {
                tmp2.performed += sandMassageOnperformed;
                tmp2.started +=sandMassageOnStar;
                tmp2.canceled += sandMassageOnCancel;
            }
        }
        return true;
    }
    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    {
        return (IMyModel)this.MemberwiseClone();
    }
    ModelEventMassage IMyModel.GetEventMassage()
    {
        return modelEventMassage;
    }
    IModelMassage IMyModel.GetModelMassage()
    {
        throw new System.NotImplementedException();
    }
    void IMyModel.SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }

    public List<string> GetEventList()
    { 
        return new List<string>();
    }
    private void sandMassageOnperformed(CallbackContext context) 
    {
        if (context.action.name == "move")
        {
           
            SendNotification("PlayerMoveCommand", context);
        }
        if (context.action.name == "weapen") 
        {
            SendNotification("PlayerControlCommand", context);
        }
    }
    private void sandMassageOnStar(CallbackContext context)
    {
        if (context.action.name == "run"|| context.action.name=="slow")
        {
            SendNotification("PlayerMoveCommand", context);
        }
        if (context.action.name == "skill1"||
            context.action.name == "skill2"||
            context.action.name == "skill3"||
            context.action.name == "skill4"|| 
            context.action.name == "flash")
        {
            SendNotification("PlayerSkillCommand", context);
        }
        if (context.action.name == "Paurse"||
            context.action.name == "Baggade"||
            context.action.name == "skillPanel")
        {
            SendNotification("SystemControlCommand", context);
        }
    }

    private void sandMassageOnCancel(CallbackContext context)
    {
        if (context.action.name == "run")
        {
            Facade.SendNotification("PlayerMoveCommand", context);
        }
        if (context.action.name == "slow")
        {
            Facade.SendNotification("PlayerMoveCommand", context);
        }
    }
    public bool changeBindingPath(string actionMaps, string ActionName, string newPath, string defineKey) 
    {
        IInputActionCollection2 inputActions;
        if (!(InputClassDic.TryGetValue(actionMaps, out inputActions)))
        {
            return false;
        }
        return changeBindingPath(inputActions, ActionName, newPath, defineKey);
    }

    public bool changeBindingPath(IInputActionCollection2 actionMaps,string ActionName, string newPath, string defineKey)
    {
        return changeBindingPath(actionMaps,actionMaps.FindAction(ActionName), newPath, defineKey);
    }

    public bool changeBindingPath(IInputActionCollection2 actionMaps,InputAction inputAction ,string newPath,string defineKey) 
    {
        if(inputAction.enabled==true) inputAction.Disable();
        int index = 0;
        InputBinding  inputBindingTmp = new InputBinding();
        foreach (var tmp in inputAction.bindings) 
        {
            if (tmp.path == defineKey) 
            {
                inputBindingTmp=tmp;
                index++;
                break;
            }
        }
        inputBindingTmp.overridePath = newPath;
        inputAction.ApplyBindingOverride(index,inputBindingTmp);
        inputAction.Enable();
        if (inputAction.enabled==true) 
        {
            return true;
        };
        return false;
    }
    private void ChangeBindPathbyUser(UsePathDate usePathDate) 
    {
        if (usePathDate.usePathDates.Length == 0) 
        { 
            changeBindingPath(usePathDate.ChangeActionMaps, usePathDate.ActionName, usePathDate.newPath, usePathDate.defineKey);
        }
        else
        {
            for (int i = 0; i < usePathDate.usePathDates.Length; i++)
            {
                this.ChangeBindPathbyUser(usePathDate.usePathDates[i]);
            }
        }
    }
}

class InputContext : EventArgs
{
    public InputContext() { }
    public InputContext(int input)
    {
        _index = input;
        _Controlkind = "int";

    }
    public InputContext(Vector2 input) 
    {
        _position = input;
        _Controlkind="Vector2";

    }
    public InputContext(object input) 
    {
        _inist_obj = input;
        _Controlkind = "object";

    }
    public InputContext(string input) 
    {
        _name=input;
        _Controlkind ="string";
    }
    #region fieldinfo
    string _Controlkind;
    int _index;
    Vector2 _position;
    object _inist_obj;
    string _name;
    #endregion
    #region property
    public int index
    {
        get { return _index; }
    }
    public Vector2 position 
    {
        get { return _position; }
    }
    public object inist_obj
    {
        get { return _inist_obj;}
    }
    public string name 
    {
        set { _name = value; }
    }
    public string ControlkindName 
    {
        get { return _Controlkind; }
    }
    #endregion

}

class UsePathDate
{
    public string Name = "";
    public string pathSetDate = "";
    public string Layer = "Main";
    public string ChangeActionMaps = "";
    public string ActionName = "";
    public string defineKey = "";
    public string newPath = "";
    public UsePathDate[] usePathDates = new UsePathDate[0];
}