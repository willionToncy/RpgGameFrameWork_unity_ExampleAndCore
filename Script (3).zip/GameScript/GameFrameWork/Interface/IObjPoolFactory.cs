using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IObjPoolFactory<T> 
{
    public IPoolInterfface<T> CreateObjPool();
}
