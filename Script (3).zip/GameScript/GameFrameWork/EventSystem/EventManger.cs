using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq.Expressions;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UIElements;

public class EventManger:ICoreHandler
{
    ICoreHandler _coreNextHandler;
    private EventManger()
    {
        initEventManger();
    }

    public static EventManger Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new EventManger();
            }
            return _instance;
        }
    }

    private static EventManger _instance;

    private Dictionary<string, EventHandler<EventArgs>> EventDictionar;
     
    public void initEventManger() 
    {
        EventDictionar=new Dictionary<string, EventHandler<EventArgs>>();
    }
    public void ExecuteCoreResqust(string modelKind, string Name)
    {
        Debug.LogWarning("EventManger do not recieve string of ModelName,Mast use class witch inherits IMyModel");
        throw new myException("Do not recieve string of ModelName,Mast use class witch inherits IMyModel");
    }

    public void ExecuteCoreResqust(IMyModel myModel, string NameInDivct)
    {
        foreach (var tmp in myModel.GetEventList())
        {
            try
            {
                AddEvent(tmp, null);
            }
            catch (EventExcepction ex)
            {
                using (StreamWriter streamWriter = new StreamWriter(Application.dataPath + "\\Date\\logs\\EventReadlogs.text", true))
                {
                    streamWriter.WriteLine(ex.Message + "/n");
                    streamWriter.WriteLine("______________________________________________");
                }

            }
        }
        foreach (KeyValuePair<string, EventHandler<EventArgs>> tmp in myModel.GetEventMassage())
        {
            try
            {
                AddEvent(tmp.Key, tmp.Value);
                return;
            }
            catch (EventExcepction ex)
            {
                using (StreamWriter streamWriter = new StreamWriter(Application.dataPath + "\\Date\\logs\\EventReadlogs.text", true))
                {
                    streamWriter.WriteLine(ex.Message + "/n");
                    streamWriter.WriteLine("______________________________________________");
                    streamWriter.Close();
                    streamWriter.Dispose();
                }

            }
            Subscribe(tmp.Key, tmp.Value);
        }
    }

    public ICoreHandler GetCoreNextHandler()
    {
        return _coreNextHandler;
    }

    public void SetCoreNextHandler(ICoreHandler data)
    {
        _coreNextHandler = data;
    }
    public void AddEvent(string eventName, EventHandler<EventArgs> tmp) 
    {
        foreach(KeyValuePair<string, EventHandler<EventArgs>> kvp in EventDictionar)
        {
            if (kvp.Key == eventName) 
            {
                throw new EventExcepction("Inputed key which is in EventDictionar.please check Inputed key");
            }
        }
        EventDictionar.Add(eventName, tmp);
    }
    public void RemoveEvent(string eventName) 
    {
        EventDictionar.Remove(FindEventInDict(eventName).Key);
    }
    public void ClearEvent() 
    {
        EventDictionar=null;
    }
    public bool GetEvent(string EventName ,out EventHandler<EventArgs> delegetFunction) 
    {
        return EventDictionar.TryGetValue(EventName, out delegetFunction);
    }
    public void Subscribe(string EventName, EventHandler<EventArgs> delegetFunction)
    {
        if (EventDictionar.ContainsKey(EventName))
        EventDictionar[EventName] += delegetFunction;
    }

    public void Unsubscribe(string EventName, EventHandler<EventArgs> delegetFunction) 
    {
        if (EventDictionar.ContainsKey(EventName))
            EventDictionar[EventName] -= delegetFunction;
    }

    public void PublishMassage(string EventMassage,object sander, EventArgs agrs) 
    {
        FindEventInDict(EventMassage).Value?.Invoke(sander, agrs);
    }
    public void PublishMassage(string EventMassage, object sander)
    {
        PublishMassage(EventMassage, this, EventArgs.Empty);
    }

    #region �ڲ���������
    private KeyValuePair<string, EventHandler<EventArgs>> FindEventInDict(string EventMassage) 
    {
        foreach (KeyValuePair<string, EventHandler<EventArgs>> valuePairs in EventDictionar)
        {
            if (valuePairs.Key == EventMassage)
            {
                return valuePairs;
            }
        }
        return new KeyValuePair<string, EventHandler<EventArgs>>("Null", null);
    }
    #endregion
}
