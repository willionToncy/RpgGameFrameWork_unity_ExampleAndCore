using NUnit.Framework;
using NUnit.Framework.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using Unity.Collections;
using Unity.Jobs;
using UnityEditor;
using UnityEditor.Build.Pipeline;
using UnityEditor.Rendering;
using UnityEngine;
using static Unity.Burst.Intrinsics.X86.Avx;

public class GameObjectJobSystemMgr : MonoBehaviour
{
    #region �ⲿ��������
    public bool AddDateAndJob(IMyJobSystemDate gameObject, IMyJobSystemJob jobSystemJob,int IndexID, string gameObjectName) 
    {
        try 
        {
            AddGameObjectJob(jobSystemJob, IndexID);
            AddGameObject(gameObject, IndexID, gameObjectName);
            return true;
        }
        catch (Exception ex)
        {
            Debug.LogWarning(ex);
        }
        return false;
    }
    public bool AddDateAndJob(LinkedList<IMyJobSystemDate> gameObjects, IMyJobSystemJob jobSystemJob, int IndexID, string gameObjectName) 
    {
        try
        {
            AddGameObjectJob(jobSystemJob, IndexID);
            AddGameObjectList(gameObjects, IndexID, gameObjectName);
            return true;
        }
        catch (Exception ex)
        {
            Debug.LogWarning(ex);
        }
        return false;
    }
    public bool AddGameObject(IMyJobSystemDate gameObject ,int IndexID , string gameObjectName)
    {
        if (JobDir.ContainsKey(IndexID)==false) 
        {
            throw new Exception("δѹ���¼��������������������ֹ");
        }
        else
        {
            if (GameObjectDir.ContainsKey(gameObjectName))
            {
                GameObjectDir[gameObjectName].AddLast(gameObject);
            }
            else
            {
                LinkedList<IMyJobSystemDate> myJobSystemDates = new LinkedList<IMyJobSystemDate>();
                myJobSystemDates.AddFirst(gameObject);
                GameObjectDir.Add(gameObjectName, myJobSystemDates);
            }
            if (JobIndexDict.ContainsKey(gameObjectName) ==false)
            {
                JobIndexDict.Add(gameObjectName, IndexID);
            }
            return true;
        }
    }
    public bool AddGameObjectList(LinkedList<IMyJobSystemDate> gameObject, int IndexID, string gameObjectName)
    {
        if (JobDir.ContainsKey(IndexID) == false)
        {
            throw new Exception("δѹ���¼��������������������ֹ");
        }
        else
        {
            if (GameObjectDir.ContainsKey(gameObjectName))
            {
                throw new Exception($"List�Ѿ�����,List���ƣ�{gameObjectName}");
            }
            else
            {
                GameObjectDir.Add(gameObjectName, gameObject);
            }
            if (JobIndexDict.ContainsKey(gameObjectName) == false)
            {
                JobIndexDict.Add(gameObjectName, IndexID);
            }
            return true;
        }
    }
    public bool AddGameObjectJob(IMyJobSystemJob jobSystemJob,int IndexID)
    {
        if (JobDir.ContainsKey(IndexID))
        {
            throw new Exception("�Ѵ����¼�");
        }
        else 
        {
            JobDir.Add(IndexID, jobSystemJob);
            return true;
        }
    }
    public bool RemoveObjectJob(int IndexID) 
    {
        JobDir.Remove(IndexID);
        foreach (KeyValuePair<string, int> tmp in JobIndexDict) 
        {
            if (IndexID==tmp.Value) 
            {
                GameObjectDir.Remove(tmp.Key);
                JobIndexDict.Remove(tmp.Key);
                return true;
            }
        }
        return false;
    }
    public bool RemoveGameObject(IMyJobSystemDate myJobSystemDate,string Name) 
    {
        foreach (var tmp in GameObjectDir[Name]) 
        {
            if (tmp.Equals(myJobSystemDate)) 
            {
                GameObjectDir[Name].Remove(tmp);
                if (GameObjectDir[Name].Count == 0) 
                {
                    RomoveGameObjectList(Name);
                }
                return true;
            }
        }
        return false;
    }
    public bool RomoveGameObjectList(string Name) 
    {
        GameObjectDir.Remove(Name);
        JobDir.Remove(JobIndexDict[Name]);
        JobIndexDict.Remove(Name);
        return true;
    }
    public bool HasJob(IMyJobSystemJob myJobSystemJob) 
    {
        return JobDir.ContainsValue(myJobSystemJob);
    }
    public bool HasJob(int Index) 
    {
        return JobDir.ContainsKey(Index);
    }
    public bool HasJob(string ObjectName) 
    {
        if (JobIndexDict.ContainsKey(ObjectName)) 
        {
            return JobDir.ContainsKey(JobIndexDict[ObjectName]);
        }
       return false ;
    }
    public bool HasJobSystemDate(string Name,IMyJobSystemDate myJobSystemDate)
    {
        if (GameObjectDir.ContainsKey(Name)) 
        {
            foreach (var tmp in GameObjectDir[Name])
            {
                if (tmp.Equals(myJobSystemDate)) { return true; }
            }
            return false;
        }
       return false;
    }
    #endregion

#region Coreʹ�õĺ������ݣ�ȫ��˽�н�ֱֹ�ӷ���
    //��Ҫ����������б��ֵ�
    Dictionary<string,LinkedList<IMyJobSystemDate>> GameObjectDir;
    Dictionary<string,int> JobIndexDict;
    //��ֵΪ����������ID
    Dictionary<int, IMyJobSystemJob> JobDir;
    Dictionary<int, NativeArray<int>> InputIntDic;
    Dictionary<int, NativeArray<float>> InputFloatDic;
    Dictionary<int, JobHandle> JobHandleDir;
    Dictionary<int, NativeArray<int>> OutputIntDic;
    Dictionary<int, NativeArray<float>> OutputFloatDic;
    NativeArray<JobHandle> JobHandles;
    List<int> List_inputInt;
    List<float> List_inpufloat;
    #endregion

    #region ���Ĵ���Core
    void Start()
    {
        JobIndexDict= new Dictionary<string, int>();
        InputIntDic = new Dictionary<int, NativeArray<int>>();
        InputFloatDic = new Dictionary<int, NativeArray<float>>();
        JobHandleDir= new Dictionary<int, JobHandle>();
        OutputIntDic= new Dictionary<int, NativeArray<int>>();
        OutputFloatDic=new Dictionary<int, NativeArray<float>>();
        GameObjectDir =new Dictionary<string,LinkedList<IMyJobSystemDate>>();
        JobDir=new Dictionary<int, IMyJobSystemJob>();
        TestDate testDate = new TestDate();
        TestJob testJob = new TestJob();
        AddDateAndJob(testDate,testJob,1,"Test1");
    }

    // Update is called once per frame
    void Update()
    {
        List_inputInt = new List<int>();
        List_inpufloat = new List<float>();
        JobHandles =new NativeArray<JobHandle>(GameObjectDir.Count,Allocator.TempJob);
        int IndexJobHandles = 0;
        foreach (KeyValuePair<string, LinkedList<IMyJobSystemDate>> tmp in GameObjectDir)
        {
            int IndexID = JobIndexDict[tmp.Key];
            foreach (IMyJobSystemDate tmpDate in tmp.Value)
            {
                foreach (var ObjDate in tmpDate.GetDateToInts())
                {
                    List_inputInt.Add(ObjDate);
                }
                foreach (var ObjDate in tmpDate.GetDateToFloat())
                {
                    List_inpufloat.Add(ObjDate);
                }
            }
            int[] IntTmpArray = List_inputInt.ToArray();
            float[] FLoatTmpArray = List_inpufloat.ToArray();
            InputIntDic[IndexID] = new NativeArray<int>(IntTmpArray, Allocator.TempJob);
            InputFloatDic[IndexID] = new NativeArray<float>(FLoatTmpArray, Allocator.TempJob);
            JobHandleDir[IndexID]= JobDir[IndexID].Init(InputFloatDic[IndexID], InputIntDic[IndexID]).Excute(tmp.Value.Count, 4);
            JobHandles[IndexJobHandles] = JobHandleDir[IndexID];
            IndexJobHandles++;
        }
    }

    private void LateUpdate()
    {
        JobHandle jh = JobHandle.CombineDependencies(JobHandles);
        jh.Complete();
        foreach (KeyValuePair<string, LinkedList<IMyJobSystemDate>> tmp in GameObjectDir)
        {
            int IndexID = JobIndexDict[tmp.Key];
            OutputIntDic[IndexID]= JobDir[IndexID].GetOutints();
            OutputFloatDic[IndexID]=JobDir[IndexID].GetOutfloats();
            int[] tmpInts= OutputIntDic[IndexID].ToArray();
            float[] tmpDoubles= OutputFloatDic[IndexID].ToArray();
            int indexConut=0;
            foreach (IMyJobSystemDate tmpDate in tmp.Value)
            { 
                List<int> tmpDateInts= new List<int>();
                List<float> tmpDateFloats= new List<float>();
                for (int i=0;i< tmpDate.GetIntsLength();i++ ) 
                {
                    tmpDateInts.Add(tmpInts[i+ indexConut]);
                    tmpDate.SetDateByint(tmpDateInts);
                }
                tmpDate.GetfloatLength();
                for (int i = 0; i < tmpDate.GetfloatLength(); i++) 
                {
                    tmpDateFloats.Add(tmpDoubles[i + indexConut]);
                    tmpDate.SetDateByFloat(tmpDateFloats);
                }
                indexConut++;
            }
            InputIntDic[IndexID].Dispose();
            InputFloatDic[IndexID].Dispose();
            try 
            {
                OutputIntDic[IndexID].Dispose();
                OutputFloatDic[IndexID].Dispose();
            }
            catch (Exception ex)
            {
                Debug.LogWarning(ex);
            }
        }
        JobHandles.Dispose();
    }


    public class TestDate : IMyJobSystemDate
    {
        List<float> floats = new List<float>();
        List<int> ints = new List<int>();
        List<float> IMyJobSystemDate.GetDateToFloat()
        {
            
            floats.Add(1.0f);
            return floats;
        }

        List<int> IMyJobSystemDate.GetDateToInts()
        {
          
            ints.Add(2);
            return ints;
        }

        int IMyJobSystemDate.GetfloatLength()
        {
            return 1;
        }

        int IMyJobSystemDate.GetIntsLength()
        {
            return 1;
        }

        bool IMyJobSystemDate.SetDateByFloat(List<float> Date)
        {
            Debug.Log(Date[0]);
            floats[0]=1.0f;
            return true;
        }

        bool IMyJobSystemDate.SetDateByint(List<int> Date)
        {
            Debug.Log(Date[0]);
            ints[0] = 2;
            return true;
        }
        
    }

    public class TestJob : IMyJobSystemJob 
    {

        NativeArray<float> _Infloats;
        NativeArray<int> _Inints;
        IJobParallelFor _job;
        public JobHandle Excute(int batchArray,int batchCount)
        {
            Job_1 _job = new Job_1();
            _job.Infloats = _Infloats;
            _job.Inints = _Inints;

            return _job.Schedule(batchArray, batchCount);
        }

        public NativeArray<float> GetOutfloats()
        {
            return _Infloats;
        }

        public NativeArray<int> GetOutints()
        {
            return _Inints;
        }

        public IMyJobSystemJob Init(NativeArray<float> Infloats, NativeArray<int> Inints)
        {
            _Infloats = Infloats;
            _Inints = Inints;
            return this;
        }

        struct Job_1 : IJobParallelFor 
        {
            public NativeArray<float> Infloats;
            public NativeArray<int> Inints;
            public void Execute(int index)
            {
                Debug.Log("���̼߳���");
                Debug.Log(Infloats[index]);
                Debug.Log(Inints[index]);
                Infloats[index] = 10.5f;
                Inints[index] = 10;
            }
        }
    }
    #endregion
}
