using JetBrains.Annotations;
using Mono.Cecil;
using PureMVC.Core;
using PureMVC.Interfaces;
using PureMVC.Patterns.Facade;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Xml.Linq;
using Unity.VisualScripting;
using UnityEngine;

public class ModelMager:ICoreHandler
{
    private ICoreHandler _coreNextHandler;
    private static ModelMager _instance;
    private Dictionary<Type, Dictionary<string, IMyModel>> _ModelDictionary;
    public static ModelMager Instance 
    {
        get
        {
            if (_instance == null) 
            {
                _instance = new ModelMager();
            }
            return _instance;
        }
    }
    private ModelMager() 
    {
        if(_instance!=null) throw new SintonExecption("ModelMager \"New()\" function has called");
        _ModelDictionary=new Dictionary<Type, Dictionary<string, IMyModel>>();
        _coreNextHandler=EventManger.Instance;
    }
    /// <summary>
    /// �Զ���Model���������ӷ�������һ������Ϊmodelʵ�����ڶ�������Ϊ�Զ��������
    /// </summary>
    /// <param name="tmp"></param>
    /// <param name="Name"></param>
    public void ExecuteCoreResqust(string modelKind, string NameInDivct)
    {
        Type type = Type.GetType(modelKind);
        IMyModel myModel = (IMyModel)Activator.CreateInstance(type);
        AddModle(myModel, NameInDivct);
        _coreNextHandler?.ExecuteCoreResqust(myModel, NameInDivct);
    }

    public void ExecuteCoreResqust(IMyModel myModel, string NameInDivct)
    {
        AddModle(myModel, NameInDivct);
        _coreNextHandler?.ExecuteCoreResqust(myModel, NameInDivct);
    }

    public ICoreHandler GetCoreNextHandler()
    {
        return _coreNextHandler;
    }
    public void SetCoreNextHandler(ICoreHandler data)
    {
        _coreNextHandler = data;
    }

    public void AddModle(IMyModel tmp, string Name="Define") 
    {
        Dictionary<string, IMyModel> _ModelInstanceDict;
        if (_ModelDictionary.ContainsKey(tmp.GetType())!=true) 
        {
            _ModelInstanceDict = new Dictionary<string, IMyModel>();
            _ModelDictionary.Add(tmp.GetType(), _ModelInstanceDict);
        }
        _ModelDictionary.TryGetValue(tmp.GetType(), out _ModelInstanceDict);
        _ModelInstanceDict.Add(Name, tmp);
    }
    public void RemoveModle(IMyModel tmp, string Name = "Define")
    {
        string ModleKind=tmp.GetType().Name;
        Debug.LogWarning("ģ�飺"+ ModleKind + "ж��");
        RemoveModle(ModleKind ,Name);
    }
    public bool HasModle(IMyModel tmp, string Name = "Define")
    {
        string ModleKind = tmp.GetType().Name;
        return HasModle(ModleKind, Name);
    }
    /// <summary>
    /// ��һ������Ϊģ������ʱ�����أ��ڶ�������Ϊ������Ĭ��ΪDefine
    /// </summary>
    /// <param name="ModleKind"></param>
    /// <param name="Name"></param>
    public void AddModle(string ModleKind,string Name= "Define") 
    {
        AddModle(CreaterModel(ModleKind), Name) ;
    }
    public void RemoveModle(string ModleKind, string Name = "Define") 
    {
        Dictionary<string, IMyModel> _ModelInstanceDict;
        _ModelDictionary.TryGetValue(Type.GetType(ModleKind), out _ModelInstanceDict);
        _ModelInstanceDict.Remove(Name);
        if (_ModelInstanceDict.Count == 0) _ModelDictionary.Remove(Type.GetType(ModleKind));
    }
    public bool HasModle(string ModleKind, string Name = "Define")
    {
        Dictionary<string, IMyModel> _ModelInstanceDict;
        if (_ModelDictionary.TryGetValue(Type.GetType(ModleKind), out _ModelInstanceDict) == false) return false;
        return _ModelInstanceDict.ContainsKey(Name);
    } 
    public string GetKindofMVC(IMyModel Model) 
    {
        ModelTypeAttribute tmp = (ModelTypeAttribute)(Model.GetType().GetCustomAttribute(typeof(ModelTypeAttribute)));
        if (tmp.IsPureMVCModel())
        {
            return tmp.GetModelType();
        }
        else return "false";
    }

    public ModelTypeAttribute GetModelAttribute(string ModelName) 
    {
        return GetModelTypeAttribute(Type.GetType(ModelName));
    }
    public ModelTypeAttribute GetModelAttribute(IMyModel ModelObject)
    {
        return GetModelTypeAttribute(ModelObject.GetType());
    }

    #region �ڲ���������
    private ModelTypeAttribute GetModelTypeAttribute(Type type)
    {
        return (ModelTypeAttribute)type.GetCustomAttribute(typeof(ModelTypeAttribute));
    }
    private IMyModel CreaterModel(string ModleKind)
    {
        Type ModleType = Type.GetType(ModleKind);
        IMyModel myModel = (IMyModel)Activator.CreateInstance(ModleType);
        return myModel;
    }

   
    #endregion
}

