using LitJson;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
interface IConfigRead 
{
    public abstract void InitStarConfigRead(string fileRoute);
    public abstract string GetConfigDescription();
    public abstract string GetConfigKind();
    public abstract string GetConfigName();
    public abstract string GetConfigValue(string Key);
}
