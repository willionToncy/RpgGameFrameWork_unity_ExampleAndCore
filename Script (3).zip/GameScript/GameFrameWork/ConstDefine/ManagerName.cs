﻿using UnityEngine;
using System.Collections;

namespace SimpleFramework {
    public class ManagerName {
        public const string ObjectMgr = "GameObjectMgr";
        public const string GameMgr = "GameManager";
        public const string TimerMgr = "TimeManager";
        public const string MusicMgr = "MusicManager";
        public const string PanelMgr = "PanelManager";
        public const string ThreadMgr = "ThreadManager";
        public const string LoggerMgr = "LoggerSystem";
    }
}