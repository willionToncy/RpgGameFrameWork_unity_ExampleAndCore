using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns.Mediator;
using System;

[ModelType(true, false, "GameUiMgr", "Mediator")]
public class GameUiMgr : Mediator,IMyModel
{
    public new static string NAME = "GameUiMgr";
    public GameUiMgr(string Mediator) : base(Mediator) { }
    public GameUiMgr(string Mediator, object viewComponent = null) : base(Mediator, viewComponent) 
    {
    }
    bool IMyModel.Init()
    {
        return true;
    }
    public List<string> GetEventList()
    {
        throw new NotImplementedException();
    }
    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    {
        return (IMyModel)this.MemberwiseClone();
    }
    ModelEventMassage IMyModel.GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    IModelMassage IMyModel.GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    void IMyModel.SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }

    IMyModel IMyModel.GetThisObject()
    {
        throw new NotImplementedException();
    }

    IMyModel IMyModel.Clone()
    {
        throw new NotImplementedException();
    }

    List<string> IMyModel.GetEventList()
    {
        throw new NotImplementedException();
    }
}
