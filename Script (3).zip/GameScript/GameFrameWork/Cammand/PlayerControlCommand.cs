using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC;
using PureMVC.Patterns.Command;
using UnityEngine.UIElements;
using PureMVC.Interfaces;
using static UnityEngine.InputSystem.InputAction;

[ModelType(true, false, "PlayerControlCommand", "Command")]
public class PlayerControlCommand : SimpleCommand, IMyModel
{
    public bool Init()
    {
        return true;
    }
    public IMyModel Clone()
    {
        throw new System.NotImplementedException();
    }

    public override void Execute(INotification notification)
    {
        CallbackContext massage = (CallbackContext)notification.Body;
        Debug.Log(massage.action.name);
    }
    public List<string> GetEventList()
    {
        throw new System.NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    public IMyModel GetThisObject()
    {
        throw new System.NotImplementedException();
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }
}
