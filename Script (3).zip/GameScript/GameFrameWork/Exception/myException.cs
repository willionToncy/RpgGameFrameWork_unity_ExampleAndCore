using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEditor.VersionControl;
using Unity.VisualScripting.FullSerializer;

public class myException:Exception
{
    public myException() { }
    public myException(string massage) : base(massage) { }

    public myException(string message, Exception inner): base(message, inner) { }

}
