using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class SintonExecption : myException
{
    public SintonExecption() { }
    public SintonExecption(string massage) : base(massage) 
    {
    }
}
