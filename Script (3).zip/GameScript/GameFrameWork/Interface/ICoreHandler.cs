using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public  interface ICoreHandler
{
    public void ExecuteCoreResqust(string modelKind, string Name);
    public void ExecuteCoreResqust(IMyModel myModel, string NameInDivct);
    public ICoreHandler GetCoreNextHandler();
    public void SetCoreNextHandler(ICoreHandler data);

}
