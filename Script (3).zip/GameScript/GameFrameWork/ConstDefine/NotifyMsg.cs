﻿using UnityEngine;
using System.Collections;

public class NotifyMsg
{
    /// <summary>
    /// Controller层消息通知
    /// </summary>
    public const string Cmd_StartUp = "Cmd_StartUp";           //启动框架
    


    /// <summary>
    /// View层消息通知
    /// </summary>
    

}
