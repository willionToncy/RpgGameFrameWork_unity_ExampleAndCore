using PureMVC.Patterns.Proxy;
using System.Collections.Generic;
using Unity;
using Unity.VisualScripting;
using UnityEditor.AddressableAssets.HostingServices;


[ModelType(true, false, "SkillTargeMgr", "Proxy")]
public class SkillTargeMgr : Proxy,IMyModel
{
    private Dictionary<string, List<ISkillTarge>> _skillTargeDict;  
    public SkillTargeMgr(string proxyName, object data = null) : base(proxyName, data)
    {

    }
    #region �ӿ�ʵ��
    public bool Init()
    {
        return true;
    }
    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    {
        throw new System.NotImplementedException();
    }

    public List<string> GetEventList()
    {
        throw new System.NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }
    #endregion 
    public void AddSkillTarge(string skillName,ISkillTarge skillTarge) 
    {
        _skillTargeDict[skillName].Add(skillTarge);
    }

    public ISkillTarge GetSkillTarge(string skillName, string TargeName)
    {
        foreach(var tmp in _skillTargeDict[skillName]) 
        {
            if (tmp.Name == skillName) 
            {
                return tmp.Clone();
            }
        }
        return null;
    }
}