using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using PureMVC.Patterns;
using PureMVC.Patterns.Command;
using PureMVC.Interfaces;
using static UnityEngine.InputSystem.InputAction;

[ModelType(true,false, "SystemControlCommand", "Command")]
public class SystemControlCommand : SimpleCommand, IMyModel
{
    public bool Init()
    {
        return true;
    }
    public override void Execute(INotification notification)
    {
        CallbackContext massage = (CallbackContext)notification.Body;
        Debug.Log(massage.action.name);
    }
    public List<string> GetEventList()
    {
        throw new System.NotImplementedException();
    }

    public ModelEventMassage GetEventMassage()
    {
        throw new System.NotImplementedException();
    }

    public IModelMassage GetModelMassage()
    {
        throw new System.NotImplementedException();
    }

    public void SetModelMassage(IModelMassage modelMassage)
    {
        throw new System.NotImplementedException();
    }
    public IMyModel GetThisObject()
    {
        return this;
    }

    public IMyModel Clone()
    { 
        return (IMyModel)this.MemberwiseClone();
    }

    
}
