using Unity.VisualScripting;
using UnityEngine;

public interface ISkillManager 
{
    public GameObject GetSkillReleaseObj();
    public string GetSkillMgrName();
}