using Unity;
using UnityEngine;
public struct SkillReleaseDate 
{
    public float CdTime;
    public int Mp;
    public int Hp; 
}