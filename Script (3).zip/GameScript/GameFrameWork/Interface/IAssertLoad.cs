using UnityEngine.InputSystem.Utilities;
using UnityEngine;

public interface IAssertLoad
{
    public Object Load(string path, string Name);
    public T Load<T>(string path) where T : Object;
}   