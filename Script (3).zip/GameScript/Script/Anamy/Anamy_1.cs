using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEditor.Tilemaps;
using UnityEngine;
using UnityEngine.UIElements;

[BurstCompile]
public class Anamy_1 : MonoBehaviour
{
    [SerializeField]
    List<GameObject> List_GameObject;
    JobHandle jobHandle;
    MoveJob moveJob;
    NativeArray<Vector3> result;
    // Start is called before the first frame update
    void Start()
    {
        Application.targetFrameRate = 210;   
        List_GameObject = new List<GameObject>();
        transform.position = Vector3.zero;
    }

    // Update is called once per frame
    void Update()
    {
        //result = new NativeArray<Vector3>(10000, Allocator.TempJob);
        //moveJob = new MoveJob();
        //moveJob.MoveDict = Vector3.forward;
        //moveJob.position = transform.position;
        //moveJob.speed = 0.0005f;
        //moveJob.result = result;
        //jobHandle = moveJob.Schedule(100, 1);
    }
    private void LateUpdate()
    {
        Vector3 t = Vector3.zero;
        jobHandle.Complete();
        for (int i=0;i<50;i++)
        {
            t =  moveJob.result[i]+ moveJob.result[50+i];
        }
        transform .position = t+transform.position;
        result.Dispose();
    }
    
    struct MoveJob : IJobParallelFor
    {
        public Vector3 position;
        public Vector3 MoveDict;
        public float speed;
        public NativeArray<Vector3> result;
        public void Execute(int index)
        {
            result[index] = speed * MoveDict;
        }
    }
}
