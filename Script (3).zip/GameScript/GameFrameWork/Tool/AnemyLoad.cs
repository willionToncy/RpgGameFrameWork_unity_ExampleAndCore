using System.Collections;
using Unity;
using UnityEngine;

class AnemyLoad : IAssertLoad
{
    public Object Load(string path, string Name)
    {
        GameObject obj = Resources.Load<GameObject>(path);
        return null;
    }

    public T Load<T>(string path) where T : Object
    {
        throw new System.NotImplementedException();
    }
}