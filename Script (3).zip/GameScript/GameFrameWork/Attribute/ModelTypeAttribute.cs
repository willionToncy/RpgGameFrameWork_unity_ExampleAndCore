using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
public class ModelTypeAttribute : Attribute
{ 
    private string _modelType;
    private bool _isOfPureMVC;
    private bool _isSubEvent;
    private string _ModelClassName;
    public ModelTypeAttribute(bool IsOfPureMVC, bool IsSubEvent,string ModelClassName, string PureMVCKind="Define") 
    {
        _isOfPureMVC = IsOfPureMVC;
        _modelType= PureMVCKind;
        _isSubEvent = IsSubEvent;
        _ModelClassName = ModelClassName;
    }
    public bool IsPureMVCModel() 
    {
        return _isOfPureMVC;
    }
    public string GetModelType() 
    {
        return _modelType;
    }

    public bool IsSubEvent() 
    {
        return _isSubEvent;
    }

    public string GetModelClassName() 
    {
        return _ModelClassName;
    }

}
